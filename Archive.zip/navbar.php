<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">Vermillion Condos</a>
		</div>
		<div id="navbar" class="navbar-collapse collapse float-right">
			<ul class="nav navbar-nav">
				<li class="nav-item nav-neighbour"><a href="neighbourhood">Neighbourhood</a></li>
				<li class="nav-item nav-homes"><a href="">Homes</a></li>
				<li class="nav-item nav-Floorplans"><a href="floor-plan">Floorplans</a></li>
				<li class="nav-item nav-about"><a href="team">Our Team</a></li>
				<li class="nav-item nav-contact"><a href="">Contact Us</a></li>
			</ul> 	 
		</div><!--/.navbar-collapse -->
	</div>
</nav>